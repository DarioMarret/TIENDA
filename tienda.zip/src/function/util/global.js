export const usuario_local = "usuario:"
export const usuario_token = "token_usuario:"
export const url = "https://rec.netbot.ec/v1"
export const dataClientes = "dataClient:"


